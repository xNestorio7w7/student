<?php
$_SESSION['msgbox_info'] = '';
$_SESSION['text_msgbox_info'] = '';

$_SESSION['msgbox_error'] = '';
$_SESSION['text_msgbox_error'] = '';